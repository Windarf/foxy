# Rókafogó játék
A játék egy sakktáblán játszható 4 sötét és 1 világos gyaloggal, 
amelyek a kezdőállásban az alábbi képen látható módon helyezkednek el. 
A sötét gylaogok a kutyák, a világos gyalog a róka. Az egyik játékos 
a kutyákat, a másik a rókát irányítja. A játékosok felváltva következnek lépni:

* A kutyák átlósan léphetnek egy mezőt, de csak előre.
* A róka szintén átlósan egy mezőt léphet, de mozoghat hátrafelé is.

A rókát irányító játékos akkor nyer, ha a fikurát a kutyák mögé vezeti. 
A kutyákat vezető játékos akkor nyer, ha a rókát olyan helyzetbe kényszeríti, 
amelyben nem tud lépni.

<p align="center">
<img src="foxcatcher.png" width="350" alt="foxcatcher"/>
</p>

# Fox-catcher game
The game is played on a chess board with 4 dark and 1 light pawn,
which are placed in the starting position as shown in the picture below.
The dark pawns are the dogs, the light pawn is the fox. One of the players
controls the dogs, the other the fox. The players take turns to move:

* The dogs may move diagonally across a square, but only forward.
* The fox can also move diagonally one space, but can move backwards.

The player controlling the fox wins if he leads the fox behind the dogs. 
The player leading the hounds wins if he forces the fox into such a position, 
in which it cannot move.

<p align="center">
<img src="foxcatcher.png" width="350" alt="foxcatcher"/>
</p>