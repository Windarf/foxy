package foxcatcher.javafx;

import foxcatcher.model.Position;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;


public class GameController {

    @FXML
    private GridPane board;

    @FXML
    private void initialize() {
        createBoard();
        setStartingState();
    }

    private void createBoard() {
        for (int col = 0; col < board.getRowCount(); col++) {
            for (int row = 0; row < board.getColumnCount(); row++) {
                StackPane stackPane = new StackPane();
                stackPane.setOnMouseClicked(this::handleMouseClick);
                stackPane.getChildren().add(new ImageView());
                board.add(stackPane, col, row);
            }
        }
    }

    private void setStartingState() {
        ImageView fox = (ImageView) board.getChildren().get(2);
        fox.setImage(new Image(getClass().getResource("/images/fox.png").toExternalForm()));

        for(int i = 57; i< 64; i+=2) {
            ImageView dog = (ImageView) board.getChildren().get(i);
            dog.setImage(new Image(getClass().getResource("/images/dog.png").toExternalForm()));
        }
    }

    @FXML
    private void handleMouseClick(MouseEvent event) {
        StackPane square = (StackPane) event.getSource();
        int row = GridPane.getRowIndex(square);
        int col = GridPane.getColumnIndex(square);
        Position clickedPosition = new Position(row, col);
        System.out.printf("Click on square (%d,%d)%n", row, col);

    }
}